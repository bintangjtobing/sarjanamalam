<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class provinsiDB extends Model
{
    protected $table = 'provinces';
}
