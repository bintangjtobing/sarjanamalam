<footer class="mastfoot mt-auto">
    <div class="inner">
        <a href="/about" class="ml-2">About</a>
        <a href="/private" class="ml-2">Privasi</a>
        <a href="/help" class="ml-2">Bantuan</a>
        <a href="/feedback" class="ml-2">Umpan balik</a>
        <a href="/how-search-works">Cara kerja penelusuran</a>
        <a class="ml-2">|</a>
        <a>&copy; 2019 Sarjanamalam</a>
    </div>
    <div class="inner">

    </div>
</footer>
</div>
