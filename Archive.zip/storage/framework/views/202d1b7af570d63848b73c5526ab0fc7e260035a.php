<?php $__env->startSection('discover','Messages'); ?>
<?php $userMod = app('App\UserMod'); ?>
<?php $__env->startSection('content'); ?>
<?php $tokens  = bin2hex(openssl_random_pseudo_bytes(64)); ?>
<div id="blog">
    <div class="post-item">
        <div class="card">
            <div class="card-body">
                <div class="card-text">
                    <div class="row">
                        <div class="col-lg-3 text-left" style="padding-right:0px;">
                            <div class="media mb-4">
                                <input type="search" name="" class="form-control" placeholder="Cari pesan..."
                                    id="searchmessages">
                            </div>
                            <div class="scroll-user-active">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="user media select-media" id="<?php echo e($user->id); ?>">
                                    <img class="mr-3 img-messagesuser" src="<?php if(!$user->displaypic): ?><?php echo e(asset('https://res.cloudinary.com/sarjanamalam/image/upload/v1583995015/sa-default_mdrqnt.png')); ?>

                                        <?php else: ?>
                                        <?php echo asset('https://res.cloudinary.com/sarjanamalam/image/upload/'.$user->displaypic); ?>

                                <?php endif; ?>" alt="<?php echo e($user->name); ?> picture."><?php if($user->verified==1): ?>
                                    <span title="Verified" style="
    position: relative;
    margin-left: -15px;
    margin-top: 25px; background-color: #fff; border-radius: 50%; top: 5px;
    right: 13px;"><img src="https://res.cloudinary.com/sarjanamalam/image/upload/v1584348883/based/checkmark_ty9wnj.svg"
                                            alt="Verified" style="width:15px !important; height:15px !important;
                                            margin-left:2px;position:relative;"></span>
                                    <?php else: ?>
                                    <?php endif; ?>
                                    <div class="media-body">
                                        <h6 class="mt-0"><?php echo e($user->name); ?>

                                            
                                            <?php if($user->unread): ?>
                                            <span class="badge badge-light"><?php echo e($user->unread); ?></span>
                                            <?php endif; ?>
                                            </h5>
                                            <p class="muted-text"><?php echo e($user->email); ?></p>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="col-lg-9" id="messages">

                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum.messages.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bintangtobing/Documents/GitHub/sarjanamalam/resources/views/forum/messages/home.blade.php ENDPATH**/ ?>