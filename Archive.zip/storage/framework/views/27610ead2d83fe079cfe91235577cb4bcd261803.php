<div class="scroll-box">
    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="message clearfix" style="list-style-type:none;">
        
        <div class="<?php echo e(($message->from == Auth::id()) ? 'sent' : 'received'); ?> my-2">
            <p><?php echo e($message->message); ?></p>
            <p class="date"><?php echo e(date('d M y, h:i a',strtotime($message->created_at))); ?></p>
        </div>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="input-text">
    <input type="text" name="message" id="message" class="submit form-control my-1"
        placeholder="Tulis pesan kamu disini..." autofocus required>
</div>
<?php /**PATH /Users/bintangtobing/Documents/GitHub/sarjanamalam/resources/views/forum/messages/view.blade.php ENDPATH**/ ?>