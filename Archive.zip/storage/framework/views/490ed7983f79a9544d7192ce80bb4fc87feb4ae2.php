<?php $__env->startSection('activelog','active'); ?>
<?php $__env->startSection('titleweb',"Focus on what you're talking about | Sarjanamalam."); ?>
<?php $__env->startSection('desctitle','Masuk ke akun sarjanamalam kamu. Gabung bersama forum dan bahas tentang apa yang kamu alami dan
kamu ingin cari tau.'); ?>
<?php $__env->startSection('contentauth'); ?>
<?php $tokens=bin2hex(openssl_random_pseudo_bytes(64));?>
<?php if(session('gagal')): ?>
<div class="form-row">
    <div class="col-md-12">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Failed!</strong><br><?php echo e(session('gagal')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
</div>
<?php endif; ?>
<form action="/get-verification/<?php echo e($tokens); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input class="form-control" type="text" name="username" placeholder="Username" required autofocus>
<input class="form-control" type="password" name="password" placeholder="Password" required>
    
    <div class="form-button">
        <button id="submit" type="submit" class="ibtn">Login</button></form> <a href="" data-toggle="modal"
    data-target="#forgetPassword">Forget password?</a>

<!-- Modal password -->
<div class="modal fade" id="forgetPassword" tabindex="-1" role="dialog" aria-labelledby="forgetPassword"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="forgetPassword"><b>Kembalikan akun anda.</b></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="/reset-account" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="modal-body">
                    <p style="color:#121212; font-weight:300;">Ketik username yang anda daftarkan pertama kali,
                        dan
                        kami akan
                        mengirimkan instruksi reset
                        akun ke email yang berhubungan dengan username anda.</p>
                    <input type="text" name="username" class="form-control form-reset"
                        placeholder="Masukkan username anda" autofocus required>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Reset akun</button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.signin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bintangtobing/Documents/GitHub/sarjanamalam/resources/views/homepage/login.blade.php ENDPATH**/ ?>