<?php $__env->startSection('title','- Login'); ?>
<?php $__env->startSection('content'); ?>
<div class="cover-container-fluid d-flex w-100 h-100 p-4 flex-column">
    <header class="masthead mb-auto">
        <div class="inner">
            <nav class="nav nav-masthead justify-content-end">
                <a class="nav-link" href="/register" hidden>Masuk</a>
            </nav>
        </div>
    </header>
    <div class="container text-center">
        <?php $tokens= bin2hex(openssl_random_pseudo_bytes(64)); ?>
        <form action="/get-verification/<?php echo e($tokens); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="login text-left">
                <h3><strong>Masuk</strong></h3>
                <p>Masuk untuk melanjutkan ke <strong>Sarjanamalam</strong>.</p>
                <?php if(session('sukses')): ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <h4 class="alert-heading">Congratulations!</h4>
                            <p>Yeay! Kamu berhasil mendaftar keanggotaan di <strong>Sarjanamalam</strong>!</p>
                            <p class="mb-0"><?php echo e(session('sukses')); ?> <strong><a
                                        href="https://instagram.com/sarjanamalamdotcom" target="_blank"
                                        data-toggle="tooltip" data-placement="bottom"
                                        title="Follow us on Instagram!">sarjanamalam</a></strong> loh.</p>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    </div>
                </div>
                <?php elseif(session('gagal')): ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <h4 class="alert-heading">Sign in failed!</h4>
                            <p class="mb-0"><?php echo e(session('gagal')); ?></p>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <input type="text" name="username" id="username" class="form-control" placeholder="Username / Email"
                    required>
                <input type="password" name="password" id="password" class="form-control" placeholder="Password"
                    required>
                <small class="form-text mb-3"><a href="/forgotpassword">Lupa password/email?</a></small>
                <button type="submit" class="btn btn-sarjana">Masuk</button>
                <small class="form-text mt-4">Belum punya akun? <a href="/daftar/<?php echo e($tokens); ?>">Buat akun!</a></small>
            </div>
        </form>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bintangtobing/Documents/GitHub/sarjanamalam/resources/views/homepage/signin.blade.php ENDPATH**/ ?>