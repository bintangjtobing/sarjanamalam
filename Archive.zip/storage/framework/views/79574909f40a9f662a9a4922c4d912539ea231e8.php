<?php $userMod = app('App\UserMod'); ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sarjanamalam Forum :: <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="<?php echo asset('storage/webicon.png'); ?>" type="image/x-icon">
    <script src="https://kit.fontawesome.com/ae026c985d.js" crossorigin="anonymous"></script>
    <meta name="title" content="Sarjanamalam Forum :: <?php echo $__env->yieldContent('title'); ?>">
    <meta name="description"
        content="Complex search engine, including discussions in the community system. Sarjanamalam can help you in your lectures and daily activities.">
    <meta name="language" content="English">
    <meta name="author" content="Sarjanamalam.">
    <?php $tokens  = bin2hex(openssl_random_pseudo_bytes(64)); ?>

    
    <link rel="stylesheet" href="<?php echo asset('css/newforum/newstyle.css'); ?>">
    <link href="<?php echo asset('css/new/css/plugins.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('css/new/css/style.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('css/new/css/red.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('css/new/css/event-style.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('css/new/css/font-awesome.css'); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo asset('css/themify-icons.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/new/css/custom.css'); ?>">

    
    <meta property="fb:admins" content="114499413304839">
    <meta property="og:site_name" content="<?php echo $__env->yieldContent('title'); ?>" />
    <meta property="og:url" content="<?php echo e(Request::url()); ?>" />
    <meta property="og:type" content="<?php echo $__env->yieldContent('ogtype'); ?>" />
    <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>" />
    <meta property="og:description" content="<?php echo $__env->yieldContent('metadesc'); ?>" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>

<body>

    
    <div class="body-inner">
        <header id="header" data-fullwidth="true" class="header-alternative">
            <div class="header-inner">
                <div class="container">

                    <div id="logo">
                        <a href="/">
                            <img src="<?php echo asset('storage/logoofficial-mini.png'); ?>" data-toggle="tooltip"
                                data-placement="bottom" title="Back to homepage" class="logo-default">
                        </a>
                    </div>
                    <div class="header-extras">
                        <ul>
                            <li>
                                <a href="/messages/<?php echo e($tokens); ?>">
                                    <img src="https://res.cloudinary.com/sarjanamalam/image/upload/v1583810435/based/paper-plane_tbosw0.svg"
                                        class="chaticon-forum mx-2" data-toggle="tooltip" data-placement="bottom"
                                        title="Private Messages"></a>
                            </li>
                            <li>
                                <div class="p-dropdown">
                                    <a href="#"><img
                                            src="<?php if(!auth()->user()->displaypic): ?><?php echo asset('https://res.cloudinary.com/sarjanamalam/image/upload/v1583995015/sa-default_mdrqnt.png'); ?>

                                            <?php else: ?><?php echo asset('https://res.cloudinary.com/sarjanamalam/image/upload/'.auth()->user()->displaypic); ?><?php endif; ?>"
                                            alt="Profile picture"
                                            class="img-roundedforum"></a><?php if(auth()->user()->verified==1): ?>
                                    <span title="Verified" style="
    position: relative;
    margin-left: -15px;
    margin-top: 25px; background-color: #fff; border-radius: 50%; top: 15px;
    right: 3px;"><img src="https://res.cloudinary.com/sarjanamalam/image/upload/v1584348883/based/checkmark_ty9wnj.svg"
                                            alt="Verified" style="width:15px !important; height:15px !important;
                                            margin-left:2px;position:relative;"></span>
                                    <?php else: ?>
                                    <?php endif; ?>
                                    <?php $enc_id = Crypt::encrypt(auth()->user()->id); ?>
                                    <ul class="p-dropdown-content">
                                        <?php $enc_id = base64_encode(auth()->user()->id) ?>
                                        <li><a><b><?php echo e(auth()->user()->name); ?></b></a></li>
                                        <hr>
                                        <li><a href="/<?php echo e(auth()->user()->username); ?>">Dashboard Profile</a>
                                        </li>
                                        <li><a href="/<?php echo e(auth()->user()->username); ?>/settings">Settings</a>
                                        </li>
                                        <li><a href="/logout/<?php echo e(auth()->user()->id); ?>/<?php echo e($tokens); ?>">Sign out</a></li>
                                    </ul>
                                </div>
                            </li>

                        </ul>
                    </div>


                    <div id="mainMenu-trigger">
                        <a class="lines-button x"><span class="lines"></span></a>
                    </div>
                    <div id="mainMenu" class="menu-center menu-lowercase">
                        <div class="container">
                            <nav>
                                <ul>
                                    <li class="dropdown"><a href="#"><?php echo $__env->yieldContent('discover'); ?> <i
                                                class="fas fa-caret-down"></i></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="/forum/<?php echo e($tokens); ?>"
                                                    class="<?php echo $__env->yieldContent('aktifdw-threads'); ?>">Threads</a></li>
                                            <li><a href="/search-events/<?php echo e($tokens); ?>"
                                                    class="<?php echo $__env->yieldContent('aktifdw-events'); ?>">Events</a>
                                            </li>
                                            <li><a href="/jobs/<?php echo e($tokens); ?>" class="<?php echo $__env->yieldContent('aktifdw-jobs'); ?>">Jobs</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <form action="" method="get"><input type="search" class="search-for"
                                                placeholder="Search topic here..." name="get_value" id="" value="">
                                        </form>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>

                </div>
            </div>
        </header>


        <section id="page-content" class="sidebar-both">
            <div class="container">
                <div class="row">
                    <div class="content col-lg-9">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                    <div class="sidebar sticky-sidebar col-lg-3">
                        <div class="widget widget-tags mb-3">
                            <h3 class="widget-title">5 Trendic Topics</h3>
                            <ul class="list list-arrow-icons">
                                <?php $__currentLoopData = $countdesc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $enc_id = Crypt::encrypt($count->id); ?>
                                <li class="lilist"><a class="trend-list"
                                        href="/details/<?php echo e($enc_id); ?>/"><?php echo e(str_limit($count->subject, $limit=40)); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="widget mt-4" style="box-shadow:0 0 0px 0 !important;">
                            <h3>List To Do Task</h3>
                            <ul class="list-group">
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Sarapan
                                    <span class="badge badge-danger badge-pill"><i class="fas fa-minus"></i></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <script type="application/ld+json">
        {
            "@context": "https://schema.org/",
            "@type": "WebSite",
            "name": "Sarjanamalam",
            "url": "https://sarjanamalam.com/tentang-sarjana-malam",
            "potentialAction": {
                "@type": "SearchAction",
                "target": "https://sarjanamalam.com/{search_term_string}",
                "query-input": "required name=search_term_string"
            }
        }

    </script>
    <script src="<?php echo asset('js/jquery.js'); ?>"></script>
    <script src="<?php echo asset('js/plugins.js'); ?>"></script>
    <script src="<?php echo asset('js/functions.js'); ?>"></script>
    <script type='text/javascript'
        src='https://maps.googleapis.com/maps/api/js?key=AIzaSyAZIus-_huNW25Jl7RPmHgoGZjD5udgBMI'>
    </script>
    <script src="<?php echo asset('js/gmap3.min.js'); ?>"></script>
    <script src="<?php echo asset('js/map-styles.js'); ?>"></script>
    <script src="<?php echo asset('css/new/plugins/js/infinite-scroll.min.js'); ?>"></script>

    
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
    <script src="https://cdn.tiny.cloud/1/8ll77vzod9z7cah153mxwug6wu868fhxsr291kw3tqtbu9om/tinymce/5/tinymce.min.js"
        referrerpolicy="origin"></script>
    <script>
        tinymce.init({
            selector: 'textarea#newwrite',
            toolbar: false,
            statusbar: false,
            branding: false,
            menubar: false,
            setup: function (editor) {
                editor.on('change', function (e) {
                    editor.save();
                });
            }
        });

    </script>
    <script>
        tinymce.init({
            selector: 'textarea',
            toolbar: true,
            statusbar: false,
            branding: false,
            menubar: false,
            setup: function (editor) {
                editor.on('change', function (e) {
                    editor.save();
                });
            }
        });

    </script>
    <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        })

    </script>
</body>

</html>
<?php /**PATH /Users/bintangtobing/Documents/GitHub/sarjanamalam/resources/views/forum/layouts/frontpage.blade.php ENDPATH**/ ?>