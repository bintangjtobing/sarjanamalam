<?php $userMod = app('App\UserMod'); ?>
<?php $__env->startSection('title','Sarjanamalam. | Hi there!'); ?>
<?php $__env->startSection('metadesc','Layanan berbasis situs web aplikasi, yang berguna untuk memudahkan pengguna dalam mencari tempat
untuk saling berbagi ide dan saling berinteraksi untuk merealisasikan ide tersebut.'); ?>
<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-expand-sm navbar-light mt-2">
    <div class="container">
        <div class="d-flex justify-content-end w-100" id="collapsibleNavId">
            <ul class="navbar-nav navbar-mobile ml-auto mt-2 mt-lg-0">
                <?php $tokens=bin2hex(openssl_random_pseudo_bytes(64));?>
                <?php if(Auth::check()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="/forum/<?php echo e($tokens); ?>">Forum</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/messages/<?php echo e($tokens); ?>">
                        Messages</a>
                </li>
                <?php if(auth()->user()->role=='executive'): ?>
                <li class="nav-item">
                    <a class="nav-link" href="/restricted/<?php echo e($tokens); ?>">Managements</a>
                </li>
                <?php endif; ?>
                <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="/signin/<?php echo e($tokens); ?>">Masuk</a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <span class="fas fa-ellipsis-v"></span>
                    </a>
                </li>

                <?php if(Auth::check()): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false" style="padding-top: 3px;">
                        <div class="nav-item-user">
                            <span><img
                                    src="<?php if(!auth()->user()->displaypic): ?><?php echo asset('https://res.cloudinary.com/sarjanamalam/image/upload/v1583995015/sa-default_mdrqnt.png'); ?>

                                <?php else: ?><?php echo asset('https://res.cloudinary.com/sarjanamalam/image/upload/'.auth()->user()->displaypic); ?><?php endif; ?>"
                                    class="img-profile-user" alt="User Image"></span><?php if(auth()->user()->verified==1): ?>
                            <span title="Verified" style="
    position: relative;
    margin-left: -15px;
    margin-top: 25px; background-color: #fff; border-radius: 50%;"><img
                                    src="https://res.cloudinary.com/sarjanamalam/image/upload/v1584348883/based/checkmark_ty9wnj.svg"
                                    alt="Verified"
                                    style="width:15px !important; height:15px !important; margin-left:2px;"></span>
                            <?php else: ?>
                            <?php endif; ?>
                        </div>
                    </a>
                    <div class="dropdown-menu text-center" aria-labelledby="dropdownId">
                        <a class="dropdown-item nav-user-name" href="#"><span
                                class="font-weight-bold"><?php echo e(auth()->user()->name); ?></span></a>
                        <?php
                        $getId = auth()->user()->id;
                        $enc_id = base64_encode($getId); ?>
                        <a class="dropdown-item" href="/<?php echo e(auth()->user()->username); ?>">Profile Saya</a>
                        <a href="/logout/<?php echo e(auth()->user()->id); ?>/<?php echo e($tokens); ?>" class="dropdown-item">Keluar</a>
                    </div>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <div class="row">
        <div class="col-12 text-center">
            <div>
                <form action="/search?" method="GET">
                    <?php echo csrf_field(); ?>
                    
                    
                    <?php
                    date_default_timezone_set("Asia/Jakarta");
                    $timeNow = date('H:i');
                    $Hour = date('H');

                    ?>
                    <span class="text-gradient-blue-sarjana"
                        style="font-size: 6rem; line-height:0.3em;"><?php echo e($timeNow); ?></span>
                    <h2 class="search-title text-gradient-blue-sarjana" id="titlecallback" style="line-height: 1.65;">
                        <?php if(($Hour >= 01) && ($Hour<=11)): ?> <?php echo e('Selamat pagi,'); ?> <?php elseif(($Hour>=11) && ($Hour<=15)): ?>
                                <?php echo e('Selamat siang,'); ?> <?php elseif(($Hour>=15)&& ($Hour<=18)): ?> <?php echo e('Selamat sore,'); ?>

                                    <?php else: ?><?php echo e('Selamat malam,'); ?> <?php endif; ?> <?php if(Auth::check()): ?><?php echo e(auth()->user()->name); ?> <?php else: ?>
                                    gengs! <?php endif; ?></h2> <div class="main-search">
                                    <span class="search-icon icon-left fas fa-search"></span>
                                    <input type="search" name="get_value" class="form-control"
                                        placeholder="Temukan pembahasan disini..." autofocus>
            </div>
            </form>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.welcomenew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bintangtobing/Documents/GitHub/sarjanamalam/resources/views/homepage/home.blade.php ENDPATH**/ ?>