<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>Sarjanamalam | <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="<?php echo asset('storage/webicon.png'); ?>" type="image/x-icon">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo asset('dashboard_admin/plugins/fontawesome-free/css/all.min.css'); ?>">
    <script src="https://kit.fontawesome.com/ae026c985d.js" crossorigin="anonymous"></script>

    <!-- overlayScrollbars -->
    <link rel="stylesheet"
        href="<?php echo asset('dashboard_admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css'); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo asset('dashboard_admin/dist/css/adminlte.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('dashboard_admin/dist/css/customstyle.css'); ?>">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    
    <meta name="description" content="Complex search engine Dashboard, to configuring all web.">

    
    
    <meta property="fb:admins" content="110102153747274">
    <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>">
    <meta property="og:type" content="article">
    <meta property="og:url" content="/">
    <meta property="og:image"
        content="<?php echo url('https://res.cloudinary.com/sarjanamalam/image/upload/v1584421114/based/Official_sarjanamalam_logo_copyright_2020_hecjnh.jpg'); ?>">
    <meta property="og:description" content="<?php echo $__env->yieldContent('metadesc'); ?>">
    <meta property="og:site_name" content="Sarjanamalam.">

</head>
<?php $tokens = bin2hex(openssl_random_pseudo_bytes(64)); ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Left navbar links -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="/" class="nav-link">Home</a>
                </li>
            </ul>

            <!-- SEARCH FORM -->
            <form class="form-inline ml-3">
                <div class="input-group input-group-sm">
                    <input class="form-control form-control-navbar" type="search" placeholder="Search"
                        aria-label="Search">
                    <div class="input-group-append">
                        <button class="btn btn-navbar" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
            </form>

            
        </nav>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Brand Logo -->
            <a href="javascript:window.location.reload(true)" class="brand-link">
                <img src="<?php echo asset('dashboard_admin/dist/img/sarjana_logo.jpg'); ?>" alt="AdminLTE Logo"
                    class="brand-image img-circle elevation-3" style="opacity: .8">
                <span class="brand-text font-weight-light">MANAGEMENT TOOLS</span>
            </a>

            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar user panel (optional) -->
                <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                    <div class="image">
                        <img src="<?php if(!auth()->user()->displaypic): ?><?php echo asset('https://res.cloudinary.com/sarjanamalam/image/upload/v1583995015/sa-default_mdrqnt.png'); ?>

                                <?php else: ?><?php echo asset('https://res.cloudinary.com/sarjanamalam/image/upload/'.auth()->user()->displaypic); ?><?php endif; ?>"
                            class="img-circle elevation-2" alt="Logo" . <?php echo e(auth()->user()->name); ?>>
                    </div>
                    <div class="info">
                        <a href="#" class="d-block"><?php echo e(auth()->user()->name); ?></a>
                    </div>
                </div>

                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">
                        <!-- Add icons to the links using the .nav-icon class
            with font-awesome or any other icon font library -->
                        <li class="nav-item">
                            <a href="/restricted/<?php echo e($tokens); ?>" class="nav-link <?php echo $__env->yieldContent('aktifdash'); ?>">
                                <i class="nav-icon fas fa-tachometer-alt"></i>
                                <p>
                                    Dashboard
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/user-config/<?php echo e($tokens); ?>" class="nav-link <?php echo $__env->yieldContent('aktifuser'); ?>">
                                <i class="nav-icon fas fa-users-cog"></i>
                                <p>
                                    User configurations
                                </p>
                            </a>
                        </li>

                        <li class="nav-header">SYSTEM</li>
                        <li class="nav-item">
                            <a href="/pesan/<?php echo e($tokens); ?>" class="nav-link <?php echo $__env->yieldContent('aktifinbox'); ?>">
                                <i class="nav-icon fas fa-inbox"></i>
                                <p>
                                    Inbox
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/blog/<?php echo e($tokens); ?>" class="nav-link <?php echo $__env->yieldContent('aktifblog'); ?>">
                                <i class="nav-icon fas fa-newspaper"></i>
                                <p>
                                    Blog
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/partnership/<?php echo e($tokens); ?>" class="nav-link <?php echo $__env->yieldContent('aktifpartner'); ?>">
                                <i class="nav-icon fas fa-handshake"></i>
                                <p>
                                    Partnership
                                </p>
                            </a>
                        </li>
                        <li class="nav-item has-treeview">
                            <a href="#" class="nav-link">
                                <i class="nav-icon fas fa-graduation-cap"></i>
                                <p>Event Ext.
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="/event/<?php echo e($tokens); ?>" class="nav-link <?php echo $__env->yieldContent('aktifevent'); ?>">
                                        <i class="nav-icon fas fa-calendar-check"></i>
                                        <p>
                                            Events
                                        </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="/pesertaterdaftar/<?php echo e($tokens); ?>" class="nav-link <?php echo $__env->yieldContent('aktifpeserta'); ?>">
                                        <i class="nav-icon fas fa-users"></i>
                                        <p>
                                            Registered Audience
                                        </p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item has-treeview">
                            <a href="#" class="nav-link">
                                <i class="nav-icon fab fa-ethereum"></i>
                                <p>
                                    Karir & Team
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="/karir/<?php echo e($tokens); ?>" class="nav-link <?php echo $__env->yieldContent('aktiftim'); ?>">
                                        <i class="fas fa-chess nav-icon"></i>
                                        <p>Tim pekerjaan</p>
                                    </a>
                                </li>
                            </ul>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="/sub-karir/<?php echo e($tokens); ?>" class="nav-link <?php echo $__env->yieldContent('aktifkarir'); ?>">
                                        <i class="fas fa-chess nav-icon"></i>
                                        <p>Karir</p>
                                    </a>
                                </li>
                            </ul>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="/pelamar/<?php echo e($tokens); ?>" class="nav-link <?php echo $__env->yieldContent('aktifpelamar'); ?>">
                                        <i class="fas fa-chess nav-icon"></i>
                                        <p>Kandidat Pelamar</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="/threads/<?php echo e($tokens); ?>" class="nav-link <?php echo $__env->yieldContent('aktifthreads'); ?>">
                                <i class="nav-icon fas fa-store"></i>
                                <p>
                                    Forum Threads
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/logout/<?php echo e(auth()->user()->id); ?>/<?php echo e($tokens); ?>" class="nav-link">
                                <i class="nav-icon fas fa-sign-out-alt"></i>
                                <p>
                                    Sign out
                                </p>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0 text-dark"><?php echo $__env->yieldContent('title'); ?></h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <?php echo $__env->yieldContent('content'); ?>
                <!--/. container-fluid -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->

        <!-- Main Footer -->
        <footer class="main-footer">
            <?php $YearNow = date('Y') ?>
            <strong>Copyright &copy; <?php echo e($YearNow); ?> <a href="/">Sarjanamalam</a>.</strong>
            <div class="float-right d-none d-sm-inline-block">
                <b>Version</b> 3.0.1
            </div>
        </footer>
    </div>
    <!-- ./wrapper -->

    <!-- REQUIRED SCRIPTS -->
    <!-- jQuery -->
    <script src="<?php echo asset('dashboard_admin/plugins/jquery/jquery.min.js'); ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo asset('dashboard_admin/plugins/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
    <!-- DataTables -->
    <script src="<?php echo asset('dashboard_admin/plugins/datatables/jquery.dataTables.js'); ?>"></script>
    <script src="<?php echo asset('dashboard_admin/plugins/datatables-bs4/js/dataTables.bootstrap4.js'); ?>"></script>
    <!-- overlayScrollbars -->
    <script src="<?php echo asset('dashboard_admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js'); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo asset('dashboard_admin/dist/js/adminlte.js'); ?>"></script>

    <!-- OPTIONAL SCRIPTS -->
    <script src="<?php echo asset('dashboard_admin/dist/js/demo.js'); ?>"></script>

    <!-- PAGE PLUGINS -->
    <!-- jQuery Mapael -->
    <script src="<?php echo asset('dashboard_admin/plugins/jquery-mousewheel/jquery.mousewheel.js'); ?>"></script>
    <script src="<?php echo asset('dashboard_admin/plugins/raphael/raphael.min.js'); ?>"></script>
    <script src="<?php echo asset('dashboard_admin/plugins/jquery-mapael/jquery.mapael.min.js'); ?>"></script>
    <script src="<?php echo asset('dashboard_admin/plugins/jquery-mapael/maps/usa_states.min.js'); ?>"></script>
    <!-- ChartJS -->
    <script src="<?php echo asset('dashboard_admin/plugins/chart.js/Chart.min.js'); ?>"></script>

    <!-- PAGE SCRIPTS -->
    <script src="<?php echo asset('dashboard_admin/dist/js/pages/dashboard2.js'); ?>"></script>
    <script>
        $(document).ready(function () {
            $('#tableJs').DataTable({
                "paging": true,
                "scrollY": "200px",
                "scrollCollapse": true,
                "lengthChange": true,
                "searching": true,
                "ordering": true,
                "info": true,
            });
            $('#tableItem').DataTable({
                "paging": true,
                "scrollY": "300px",
                "scrollCollapse": true,
                "lengthChange": true,
                "searching": false,
                "ordering": true,
                "info": true,
            });
        });

    </script>


    
    <script src="https://cdn.tiny.cloud/1/8ll77vzod9z7cah153mxwug6wu868fhxsr291kw3tqtbu9om/tinymce/5/tinymce.min.js"
        referrerpolicy="origin"></script>
    <script>
        tinymce.init({
            selector: 'textarea#newwrite',
            toolbar: false,
            statusbar: false,
            branding: false,
            menubar: false,
            setup: function (editor) {
                editor.on('change', function (e) {
                    editor.save();
                });
            }
        });

    </script>
</body>

</html>
<?php /**PATH /Users/bintangtobing/Documents/GitHub/sarjanamalam/resources/views/authen/index.blade.php ENDPATH**/ ?>