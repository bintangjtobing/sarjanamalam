<?php $__env->startSection('activereg','active'); ?>
<?php $__env->startSection('titleweb',"Focus on what you're talking about | Sarjanamalam."); ?>
<?php $__env->startSection('desctitle','Buat akun baru sarjanamalam kamu. Gabung bersama forum dan bahas tentang apa yang kamu alami dan
kamu ingin cari tau.'); ?>
<?php $__env->startSection('contentauth'); ?>
<?php $tokens=bin2hex(openssl_random_pseudo_bytes(64));?>
<?php if(session('sukses')): ?>
<div class="form-row">
    <div class="col-md-12">
        <div class="alert alert-success alert-dismissible fade show" id="alert-success" role="alert">
            <?php echo e(session('sukses')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
</div>
<?php endif; ?>
<?php if(count($errors)>0): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="form-row">
    <div class="col-md-12">
        <div class="alert alert-danger alert-dismissible fade show" id="alert-success" role="alert">
            <?php echo e($error); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<form action="/create-account/<?php echo e($tokens); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-row">
        <div class="col-md-12">
            <input class="form-control" type="text" name="nama_lengkap" placeholder="Nama lengkap" required autofocus>
        </div>
    </div>
    <div class="form-row">
        <div class="col-md-6">
            <input class="form-control" type="text" name="username" placeholder="Username" required>
        </div>
        <div class="col-md-6">
            <input class="form-control" type="email" name="email" placeholder="Email" required>
        </div>
    </div>
    <div class="form-row">
        <div class="col-md-6">
            <input class="form-control" type="password" name="password" id="password" placeholder="Password" required
                pattern=".{8,}">
        </div>
        <div class="col-md-6">
            <input class="form-control" type="password" name="ver_password" id="ver_password"
                placeholder="Ulangi password" required pattern=".{8,}">
        </div>
    </div>
    <div class="form-row">
        <div class="col-md-12">
            <div class="form-button">
                <button id="submit" type="submit" class="ibtn">Register</button>
            </div>
        </div>
    </div>
</form>
<script>
    function showPass() {
        var Pass = document.getElementById('password');
        if (Pass.type === "password") {
            Pass.type = "text";
        } else {
            Pass.type = "password";
        }
    }

</script>
<script>
    var Pass = document.getElementById('password');
    var Confirm_pass = document.getElementById('ver_password')

    function validatePassword() {
        if (Pass.value != Confirm_pass.value) {
            Confirm_pass.setCustomValidity("Password tidak sama. Ulangi kembali password kamu.");
        } else {
            Confirm_pass.setCustomValidity("");
        }
    }
    Pass.onchange = validatePassword;
    Confirm_pass.onkeyup = validatePassword;

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.signin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bintangtobing/Documents/GitHub/sarjanamalam/resources/views/homepage/daftar.blade.php ENDPATH**/ ?>