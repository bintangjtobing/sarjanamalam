<?php $__env->startSection('aktifthreads','active'); ?>
<?php $__env->startSection('discover','Threads'); ?>
<?php $__env->startSection('aktifdw-threads','active'); ?>
<?php $__env->startSection('title','Home'); ?>
<?php $userMod = app('App\UserMod'); ?>
<?php $__env->startSection('content'); ?>
<?php $tokens  = bin2hex(openssl_random_pseudo_bytes(64)); ?>
<div id="blog">
    <?php if(session('suksestambahdiskusi')): ?>
    <div class="post-item">
        <div class="card">
            <div class="card-body">
                <div class="card-text">
                    <div class="row">
                        <div class="col-lg-12 text-center">
                            <p><span style="font-size: 3rem; color: #4aa5e7;"><i
                                        class="far fa-check-circle"></i></span><br><span
                                    class="text-gradient-blue-sarjana">Berhasil!</span>
                                <?php echo e(session('suksestambahdiskusi')); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<div class="page-title">
    <div class="accordion accordion-shadow">
        <div class="ac-item ac-active">
            <h5 class="ac-title my-3"><i class="fa fa-rocket"></i> Bagikan topik baru</h5>
            <div class="ac-content">
                <form action="/verify-add-new-topic/<?php echo e($tokens); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="col-lg-12">
                            <label for="">Judul topik pembahasan</label>
                            <input type="text" name="subject" id="subject" class="form-control mb-3" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <label for="">Pilih kategori topik</label>
                            <select name="category" class="form-control mb-3" required>
                                <?php $__currentLoopData = $category_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->category_id); ?>"><?php echo e($cat->category); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <textarea name="threads" id="newwrite" placeholder="Tulis disini" cols="30" rows="10"
                                autofocus required></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 text-right">
                            <div class="form-group">
                                <button type="submit" class="btn btn-gradient-blue-sarjana">Buat
                                    topik</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div id="blog">

    <?php $__currentLoopData = $threadsdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="post-item">
        <div class="card">
            <div class="card-body">
                <div class="card-text">
                    <div class="row">
                        <div class="col-lg-8 text-left">
                            <p><span class="post-meta-date"><img
                                        src="<?php if(!$thread->displaypic): ?><?php echo asset('https://res.cloudinary.com/sarjanamalam/image/upload/v1583995015/sa-default_mdrqnt.png'); ?>

                                        <?php else: ?><?php echo asset('https://res.cloudinary.com/sarjanamalam/image/upload/'.$thread->displaypic); ?><?php endif; ?>"
                                        alt="img-profile-user" class="img-fluid thread-profilepic">
                                    <a href="/<?php echo e($thread->username); ?>"
                                        style="color: #3c3c3c !important; font-weight:600;"><?php echo e($thread->name); ?></a></span>
                                <?php if($thread->verified==1): ?>
                                <span title="Verified"><img
                                        src="https://res.cloudinary.com/sarjanamalam/image/upload/v1584348883/based/checkmark_ty9wnj.svg"
                                        alt="Verified"
                                        style="width:20px !important; height:20px !important; margin-left:.35rem;"></span>
                                <?php else: ?>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-lg-4 text-right">
                            <span class="text-gradient-blue-sarjana">#<?php echo e($thread->category); ?></span>
                        </div>
                    </div>
                </div>
                <div class="card-title">
                    <?php $enc_id = Crypt::encrypt($thread->id); ?>
                    <h4><a href="/details/<?php echo e($enc_id); ?>/" style="font-weight: 600;"><?php echo e($thread->subject); ?></a> </h4>
                    <p class="muted-text">Dibuat <?php echo e(Carbon\Carbon::parse($thread->created_at)->diffForHumans()); ?></p>
                </div>
                <div class="card-text">
                    <p><?php echo str_limit($thread->thread, $limit=120); ?></p>
                </div>
                <div class="card-text">
                    <div class="row">
                        <div class="col-lg-7 text-left">
                            
                            <span style="font-size: .75rem;" class="mr-2"><a href="#"><i class="far fa-eye"></i>
                                    <?php if($thread->view_count>999): ?><?php echo e($thread->view_count/1000); ?>

                                    views
                                    <?php elseif($thread->view_count>1): ?><?php echo e($thread->view_count); ?>

                                    views
                                    <?php else: ?> <?php echo e($thread->view_count); ?> view <?php endif; ?></a></span>
                            <span style="font-size: .75rem;"><a href="#"><i class="fas fa-comment"></i>
                                    <?php echo e($commentData->count()); ?> response</a></span>

                        </div>
                    </div>
                </div>
                <div class="card-text my-3">
                    <div class="row">
                        <div class="col-lg-12 text-left">
                            
                            <span style="font-size: 1rem;"><a href="/details/<?php echo e($enc_id); ?>"><i class="far fa-comment"></i>
                                    Gabung pembahasan</a></span>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>


<ul class="pagination">
    <?php echo e($threadsdata->links()); ?>

</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forum.layouts.frontpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bintangtobing/Documents/GitHub/sarjanamalam/resources/views/forum/fill/home.blade.php ENDPATH**/ ?>